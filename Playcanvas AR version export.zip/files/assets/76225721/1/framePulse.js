var FramePulse = pc.createScript('framePulse');

FramePulse.attributes.add('scaleTo', {
    type: 'vec3'
});

FramePulse.attributes.add('pulseSpeed', {
    type: 'number',
    default: 1.0
});

// initialize code called once per entity
FramePulse.prototype.initialize = function() {
    var sTo = this.scaleTo;
    var speed = this.pulseSpeed;
    
    this.entity
        .tween(this.entity.getLocalScale())
        .to(sTo, speed, pc.CubicInOut)
        .loop(true)
        .yoyo(true)
        .start();
};