Scene structure
================
Managers
|-managerFlow.js - Controls the main flow of the entire program
|-GameController.js - Controls the game portion at step 14

Transition
================
Transitions are handled via audioHander.js on end, or via button triggerNextScreen.js

AR
================
AR is handled via community translated artoolkit, artoolkit.min.js and playcanvas-ar.js, into ArCamera component, and ArMarker component

Ble
================
BLE is handled via library p5.ble.js, and managed by bleSend.js and GameController.js during game phase










Publishing
================
Follow instructions in https://developer.playcanvas.com/en/user-manual/publishing/web/playcanvas-hosting/