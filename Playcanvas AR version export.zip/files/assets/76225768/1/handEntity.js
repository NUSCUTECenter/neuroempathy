var HandEntity = pc.createScript('handEntity');

HandEntity.attributes.add('handModelEntity', {type: 'entity'});
// HandEntity.attributes.add('b1Material', {type: 'asset', assetType: 'material'});
// HandEntity.attributes.add('b6Material', {type: 'asset', assetType: 'material'});
// HandEntity.attributes.add('b12Material', {type: 'asset', assetType: 'material'});
// HandEntity.attributes.add('nbMaterial', {type: 'asset', assetType: 'material'});

// // initialize code called once per entity
// HandEntity.prototype.setMaterial = function(particleType) {
//     var material;
//     switch(particleType) {
//         case 'b1':
//             material = this.b1Material;
//             break;
//         case 'b6':
//             material = this.b6Material;
//             break;
//         case 'b12':
//             material = this.b12Material;
//             break;
//         case 'nb':
//             material = this.nbMaterial;
//             break;
//     }

//     if (!material) return;
//     var meshInstances = this.handModelEntity.model.meshInstances;
//     for (var i = 0; i < meshInstances.length; ++i) { 
//         var mesh = meshInstances[i];
//         mesh.material = material.resource;
//     }
// };

// swap method called for script hot-reloading
// inherit your script state here
// HandEntity.prototype.swap = function(old) { };

// to learn more about script anatomy, please read:
// https://developer.playcanvas.com/en/user-manual/scripting/