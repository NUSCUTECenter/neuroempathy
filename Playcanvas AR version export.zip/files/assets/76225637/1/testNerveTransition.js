var TestNerveTransition = pc.createScript('testNerveTransition');

TestNerveTransition.attributes.add('etScrollbar', { type: 'entity'});
TestNerveTransition.attributes.add('etScrollhandle', { type: 'entity'});
TestNerveTransition.attributes.add('etNerveA', { type: 'entity'});
TestNerveTransition.attributes.add('etNerveB', { type: 'entity'});
TestNerveTransition.attributes.add('etNerveC', { type: 'entity'});
TestNerveTransition.attributes.add('etGlow', { type: 'entity'});
TestNerveTransition.attributes.add('etOutline', { type: 'entity'});

TestNerveTransition.attributes.add('glowDefault', { type: 'rgb'});
TestNerveTransition.attributes.add('glowGreen', { type: 'rgb'});
TestNerveTransition.attributes.add('glowRed', { type: 'rgb'});

var lastValue;

// initialize code called once per entity
TestNerveTransition.prototype.initialize = function() {
    var sbar = this.etScrollbar;
    var eta = this.etNerveA;
    var etb = this.etNerveB;
    var etc = this.etNerveC;
    var etglow = this.etGlow;
    var etoutline = this.etOutline;
    var green = this.glowGreen;
    var red = this.glowRed;
    var ethandle = this.etScrollhandle;
    
    this.app.mouse.on(pc.EVENT_MOUSEUP, this.onMouseUp, this);
    
    
    sbar.scrollbar.on('set:value', function (value) {
        // 0 = A, 0.5 = B, 1 = C
        //console.log(value);
        var randVal = Math.random();
        randVal = randVal * 0.25;
        
        if(value < lastValue){
            // glow green
            //etglow.element.opacity = 0.25 + randVal;
            //etglow.element.color = green;
            //etoutline.element.color = green;
        }else if(value > lastValue){
            // glow red
            //etglow.element.opacity = 0.25 + randVal;
            //etglow.element.color = red;
            //etoutline.element.color = red;
        }else{
            etglow.element.opacity = 0;
        }
        // figure out A opacity
        /*if(value >= 0.5){
            eta.element.opacity = 0;
        }else{
            eta.element.opacity = 1 - (value * 2);
        }*/
        
        // figure out B opacity
        if(value <= 0.25){
            etb.element.opacity = 0;
        }else{
            etb.element.opacity = (value - 0.25) * 4;
        }
        
        // figure out C opacity
        if(value <= 0.5){
            etc.element.opacity = 0;
        }else{
            etc.element.opacity = (value - 0.5)*2;
        }
        
        lastValue = value;
    });
    
    /*
    var data;
    var tween;
    
    data = { value: 0 };
    tween = this.entity.tween(data).to({value: 1}, 0.5, pc.Linear).start();
    tween.on('update', function (dt) {
        etSprite.element.opacity = data.value;
        etSpriteB.element.opacity = 1 - data.value;
    }).on('complete', function () {
        // Load gesture
        for(var j = 0; j < etGestures.length; j++)
        {
            if(etGestures[j].name === curStepGesture.gestureID)
            {
                etGestures[j].enabled = true;
            }
        }
    });*/
};

// update code called every frame
TestNerveTransition.prototype.onMouseUp = function() {
    var etglow = this.etGlow;
    var etoutline = this.etOutline;
    var colDef = this.glowDefault;
    console.log("UP");
    
    etglow.element.opacity = 0;
    etglow.element.color = colDef;
    etoutline.element.color = colDef;
};

// swap method called for script hot-reloading
// inherit your script state here
// TestNerveTransition.prototype.swap = function(old) { };

// to learn more about script anatomy, please read:
// https://developer.playcanvas.com/en/user-manual/scripting/