var PillEntity = pc.createScript('pillEntity');

PillEntity.attributes.add('pillType', {type: 'string'});

PillEntity.attributes.add('xOffsetMultiplier', {type: 'number', default: 1});
PillEntity.attributes.add('yOffsetMultiplier', {type: 'number', default: 1});


PillEntity.prototype.initialize = function() {
    this.time = 0;
    this.duration = 1;
    this.isReleased = false;
};

// update code called every frame
PillEntity.prototype.update = function(dt) {
    if (!this.isReleased) return;
    
    this.time += dt;
    var percent = this.time / this.duration;
    var xMul = this.xOffsetMultiplier;
    var yMul = this.yOffsetMultiplier;
    
    var finalPos = this.targetEntity.getPosition();
    var x = pc.math.lerp(this.initialPosition.x, finalPos.x, percent) + QuadraticInOut(percent) * pc.math.clamp((this.offset.x * 2.5), -0.75, 0.75) * xMul;
    var y = pc.math.lerp(this.initialPosition.y, finalPos.y, percent) + QuadraticInOut(percent) * 0.5 * yMul;
    var z = pc.math.lerp(this.initialPosition.z, finalPos.z, percent);
    this.entity.setPosition(x, y, z);
    
    if (this.time > this.duration) {
        this.entity.destroy();
    }
};

PillEntity.prototype.release = function(targetEntity, offset) {
    this.isReleased = true;
    this.initialPosition = this.entity.getPosition();
    this.targetEntity = targetEntity;
    this.offset = offset;
};

function QuadraticInOut(k) {
    return 2*k * (2 - 2*k);
}