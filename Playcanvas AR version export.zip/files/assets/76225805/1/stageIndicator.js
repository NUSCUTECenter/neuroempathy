var StageIndicator = pc.createScript('stageIndicator');

StageIndicator.attributes.add('etSlider', {type: 'entity'});

// initialize code called once per entity
StageIndicator.prototype.initialize = function() {
    this.app.on('progressIndicator', this.progressIndicator, this);
};

// update code called every frame
StageIndicator.prototype.progressIndicator = function(progress) {
    //console.log("progressIndicator at: " + progress);
    var sb = this.etSlider;
    sb.scrollbar.handleSize = progress;
    //this.foreground.element.width = progress * 1080;
};