var InputTrigger = pc.createScript('inputTrigger');

InputTrigger.attributes.add('fireCommand', {type: 'string'});
InputTrigger.attributes.add('fireCommandPara', {type: 'number'});

// initialize code called once per entity
InputTrigger.prototype.initialize = function() {
    this.entity.element.on('click', function(event) {
        this.app.fire(this.fireCommand, this.fireCommandPara);
    }, this);
};
