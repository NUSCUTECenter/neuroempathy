var TransitionEntity = pc.createScript('transitionEntity');

TransitionEntity.attributes.add('transitions', {
    type: 'json',
    array: true,
    schema: [{
        name: 'targetEntity',
        type: 'entity'
    },{
        name: 'duration',
        type: 'number',
        default: 0
    }]
});

// initialize code called once per entity
TransitionEntity.prototype.initialize = function() {
    this.onStateChanged(true);
    this.on('state', this.onStateChanged, this);
};

TransitionEntity.prototype.onStateChanged = function(enabled) {
    if (enabled) {
        this.transitions.forEach(transition => {
            transition.targetEntity.enabled = false;
        });
        
        transit(0, this.transitions);
    } else {
        if (curTimeout) {
            clearTimeout(curTimeout);
        }
    }
};

var curTimeout;
function transit(idx, transitions) {
    if (idx > 0) transitions[idx-1].targetEntity.enabled = false;
    transitions[idx].targetEntity.enabled = true;
    if (idx+1 >= transitions.length) return;
    curTimeout = setTimeout(() => {
       transit(idx+1, transitions);
    },transitions[idx].duration * 1000);
}