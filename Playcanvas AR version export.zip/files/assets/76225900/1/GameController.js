var SEVERITY_FILL_TIME = 45.0;

var GameController = pc.createScript('gameController');

GameController.attributes.add('cameraEntity', {type: 'entity'});
GameController.attributes.add('handEntity', {type: 'entity'});

GameController.attributes.add('uiDamageBarMask', {type: 'entity'});
GameController.attributes.add('uiDamageBarSprite', {type: 'entity'});
GameController.attributes.add('uiDamageBarFromColour', { type: 'rgb', default: [1, 1, 1] } );
GameController.attributes.add('uiDamageBarToColour', { type: 'rgb', default: [1, 1, 1] } );

GameController.attributes.add('b1PillAnchor', {type: 'entity'});
GameController.attributes.add('b6PillAnchor', {type: 'entity'});
GameController.attributes.add('b12PillAnchor', {type: 'entity'});
GameController.attributes.add('nbPillAnchor', {type: 'entity'});

GameController.attributes.add('b1PillTemplateEntity', {type: 'asset', assetType: 'template'});
GameController.attributes.add('b6PillTemplateEntity', {type: 'asset', assetType: 'template'});
GameController.attributes.add('b12PillTemplateEntity', {type: 'asset', assetType: 'template'});
GameController.attributes.add('nbPillTemplateEntity', {type: 'asset', assetType: 'template'});

GameController.attributes.add('IntroB1', {type: 'entity'});
GameController.attributes.add('IntroB6', {type: 'entity'});
GameController.attributes.add('IntroB12', {type: 'entity'});
GameController.attributes.add('IntroNB1', {type: 'entity'});
GameController.attributes.add('IntroNB2', {type: 'entity'});

GameController.attributes.add('TutorialB1', {type: 'entity'});
GameController.attributes.add('TutorialB6', {type: 'entity'});
GameController.attributes.add('TutorialB12', {type: 'entity'});

GameController.attributes.add('TutorialEffectB1', {type: 'entity'});
GameController.attributes.add('TutorialEffectB6', {type: 'entity'});
GameController.attributes.add('TutorialEffectB12', {type: 'entity'});

GameController.attributes.add('etGameCommence', {type: 'entity'});

GameController.attributes.add('stage3MultiTarget', {type: 'entity'});
GameController.attributes.add('stage3MultiHands', {type: "entity", array: true});

GameController.attributes.add('btnGameEnd', {type: 'entity'});
GameController.attributes.add('btnNextScreen', {type: 'entity'});

// Indicators on symptom type
GameController.attributes.add('targetB1Deficiency', {type: 'entity'});
GameController.attributes.add('targetB6Deficiency', {type: 'entity'});
GameController.attributes.add('targetB12Deficiency', {type: 'entity'});

GameController.attributes.add('uiEffectB1', {type: 'entity'});
GameController.attributes.add('uiEffectB6', {type: 'entity'});
GameController.attributes.add('uiEffectB12', {type: 'entity'});
GameController.attributes.add('uiEffectNB', {type: 'entity'});
GameController.attributes.add('uiEffectWrong', {type: 'entity'});

GameController.attributes.add('effectModelsParent', {type: 'entity'});

GameController.attributes.add('degradeModelEffectB1', {type: 'entity'});
GameController.attributes.add('degradeModelEffectB6', {type: 'entity'});
GameController.attributes.add('degradeModelEffectB12', {type: 'entity'});
GameController.attributes.add('degradeModelEffectAll', {type: 'entity'});

GameController.attributes.add('regenModelEffectB1', {type: 'entity'});
GameController.attributes.add('regenModelEffectB6', {type: 'entity'});
GameController.attributes.add('regenModelEffectB12', {type: 'entity'});
GameController.attributes.add('regenModelEffectAll', {type: 'entity'});
/////////////////////////////

GameController.attributes.add('uiGameOver', {type: 'entity'});
GameController.attributes.add('uiGameWon', {type: 'entity'});

GameController.attributes.add('boolDebug', {type: 'boolean', default: false});

// initialize code called once per entity
GameController.prototype.initialize = function() {
    this.app.gameController = this;
    this.app.addTweenManager();
    
    this.pillTypes = ['b1', 'b6', 'b12', 'nb'];
    this.requiredPillTypes = ['b1', 'b6', 'b12'];
    this.spawnedPills = [null, null, null, null];
    this.pillTweens = [null, null, null, null];
    this.pickedEntity = null;
    this.pickedEntityIdx = -1;
    
    this.pillTemplateArray = [this.b1PillTemplateEntity, this.b6PillTemplateEntity, this.b12PillTemplateEntity, this.nbPillTemplateEntity];
    this.initialisePillSpawnAnchors();
    
    if (this.app.touch) {
        this.lastTouchPoint = new pc.Vec2();
        this.app.touch.on(pc.EVENT_TOUCHSTART, this.onTouchStart, this);
        this.app.touch.on(pc.EVENT_TOUCHMOVE, this.onTouchMove, this);
        this.app.touch.on(pc.EVENT_TOUCHEND, this.onTouchEnd, this);
    } else {
        this.app.mouse.on(pc.EVENT_MOUSEDOWN, this.onMouseDown, this);
        this.app.mouse.on(pc.EVENT_MOUSEMOVE, this.onMouseMove, this);
        this.app.mouse.on(pc.EVENT_MOUSEUP, this.onMouseUp, this);
    }
    
    this.ray = new pc.Ray();
    this.plane = new pc.Plane(this.nbPillAnchor.getPosition().clone(), this.nbPillAnchor.forward.clone());
    
    this.handEntity.collision.on('triggerenter', this.onHandTriggerEnter, this);
    
    this._damageBarMaskFullWidth = this.uiDamageBarMask.element.width;
    // this._barHOriW = barCurH.element.width;
    
    this.app.on('game:onTtsComplete', this.onTtsComplete, this); // Listen for nextGameState from external scripts.
    this.btnGameEnd.element.on('click', function(event) {
        this.updateGameState(17);
    }, this);
    this.btnNextScreen.element.on('click', function(event) {
        this.updateGameState(17);
    }, this);
    
    this.on('state', this.onStateChanged, this);
    
    if (this.boolDebug){
        this.updateGameState(16);
    } else {
        this.updateGameState(1); // Init game to state 1: Vitamin B1 Intro.
    }
};

GameController.prototype.onStateChanged = function(enabled) {
    this.showSpawnedPills(enabled);
    if (enabled) {
        this.currentGameState = 1;
        if (this.currentGameState != 12) this.updateGameState(this.currentGameState);
    } else {
        prevEffectTimeout = null;
        this.thrownEntity = null;
    }
};

let dtInterval = 0;
GameController.prototype.update = function(dt) {    
    if([11,15].includes(this.currentGameState)) {
        this.setDamagePct(this._damagePercent + dt / SEVERITY_FILL_TIME);
    }

    dtInterval += dt;
    if (dtInterval >= 0.1) {
        dtInterval -= 0.1;
        let val = this._damagePercent / 0.2;
        val = Math.floor(val);
        if (this.app.ble && this.app.ble.characteristics && this.app.ble.characteristics[0]) {
            this.app.ble.write(this.app.ble.characteristics[0], `${val}`);
        }
    }
};

GameController.prototype.onMouseDown = function(event) {
    if ([12,14].includes(this.currentGameState) || prevEffectTimeout) {
        // NB Intro, dont allow user to move pill
        return;
    }
    if (prevEffectTimeout) {
        // If showing correct animation, dont allow user to move pill
        return;
    }
    if (this.thrownEntity) {
        // If already throwing, down allow throw another till complete
        return;
    }
    
    
    this.mouseDownX = event.x;
    this.mouseDownY = event.y;
    
    const from = this.cameraEntity.camera.screenToWorld(event.x, event.y, this.cameraEntity.camera.nearClip);
    const to = this.cameraEntity.camera.screenToWorld(event.x, event.y, this.cameraEntity.camera.farClip);

    const result = this.app.systems.rigidbody.raycastFirst(from, to);
    if (result && result.entity) {
        this.pickedEntityIdx = this.spawnedPills.indexOf(result.entity);
        if (this.pickedEntityIdx >= 0) {
            this.pickedEntity = result.entity;
            if (this.pillTweens[this.pickedEntityIdx]) {
                this.pillTweens[this.pickedEntityIdx].stop();
            }
        }
    }
};

GameController.prototype.onMouseMove = function(event) {
    if (!this.pickedEntity) return;
    
    // Initialise the ray and work out the direction of the ray from the a screen position
    this.cameraEntity.camera.screenToWorld(event.x, event.y, this.cameraEntity.camera.farClip, this.ray.direction); 
    this.ray.origin.copy(this.cameraEntity.getPosition());
    this.ray.direction.sub(this.ray.origin).normalize();
    
    var interesecting = this.plane.intersectsRay(this.ray, hitPosition);        
    if (interesecting) {
        // Work out the vector from the box to the hitPosition
        dragPosition.sub2(hitPosition, this.pickedEntity.getPosition());
        
        // Project that vector on to the object's forward axis
        //dragPosition.project(new pc.Vec3(1,0,1));
        
        // Now move the object by that amount
        dragPosition.add(this.pickedEntity.getPosition());        
        this.pickedEntity.setPosition(dragPosition);
    }  
};

GameController.prototype.onMouseUp = function(event) {
    if (!this.pickedEntity) return;
    
    var diffMouseX = event.x - this.mouseDownX;
    var diffMouseY = event.y - this.mouseDownY;
    
    var cPos = this.pickedEntity.getLocalPosition();
    var oPos = this.pillAnchorArray[this.pickedEntityIdx].getPosition();
    var mag = oPos.distance(cPos);

    if(-diffMouseY / window.innerHeight > 0.05) { // Throw
        this.pickedEntity.script.pillEntity.release(this.handEntity, {
            x: diffMouseX / window.innerWidth, y: diffMouseY / window.innerHeight
        });
        this.thrownEntity = this.pickedEntity;
        
        // Stage 3 we spawn 2 more to new targets
        if (this.currentGameState === 15) {
            var pill2 = this.pickedEntity.clone();
            this.pickedEntity.parent.addChild(pill2);
            pill2.script.pillEntity.release(this.stage3MultiHands[0], {
                x: diffMouseX / window.innerWidth, y: diffMouseY / window.innerHeight
            });
            var pill3 = this.pickedEntity.clone();
            this.pickedEntity.parent.addChild(pill3);
            pill3.script.pillEntity.release(this.stage3MultiHands[1], {
                x: diffMouseX / window.innerWidth, y: diffMouseY / window.innerHeight
            });
        }
        
        this.spawnedPills[this.pickedEntityIdx] = null;
    } else { // Return
        this.pillTweens[this.pickedEntityIdx] = this.pickedEntity
            .tween(cPos)
            .to(oPos, 1, pc.QuadraticOut)
            .start();
    }
    
    this.pickedEntity = null;
};


GameController.prototype.onTouchStart = function(event) {
    var touch = event.touches[0];
    this.lastTouchPoint.set(touch.x, touch.y);
    this.onMouseDown(this.lastTouchPoint);
};

GameController.prototype.onTouchMove = function(event) {
    var touch = event.touches[0];
    this.lastTouchPoint.set(touch.x, touch.y);
    this.onMouseMove(this.lastTouchPoint);
};

GameController.prototype.onTouchEnd = function(event) {
    this.onMouseUp(this.lastTouchPoint);
};

GameController.prototype.onHandTriggerEnter = function(entity) {
    this.thrownEntity = null;
    switch(this.currentGameState){
        case 2: // B1 Tutorial 
        case 5: // B6 Tutorial
        case 8: // B12 Tutorial
            this.app.fire('game::tintSpotsOnHand'); //Trigger white flicker only on correct matches.
            this.updateGameState(this.currentGameState + 1);
            break;
        case 11: // Stage 1
            // this.spawnPills(false);
            break;
        case 13: // Stage 2
        case 15: // Stage 3
            // this.spawnPills(true);
            break;
    }
    
    if ([11, 13, 15].includes(this.currentGameState)) {
        const incomingPillType = entity.script.pillEntity.pillType;
        if (incomingPillType === 'nb') {
            if (this.currentGameState === 13) this.pillEffectSequence(this.requiredPillType);
            else if (this.currentGameState === 15) this.pillEffectSequence(incomingPillType);
            if (this.currentGameState === 13) this.setDamagePct(this._damagePercent - 0.15);
            else if (this.currentGameState === 15) this.setDamagePct(this._damagePercent - 0.30);
            
            this.app.fire('game::tintSpotsOnHand'); //Trigger white flicker only on correct matches.
        }
        else if (incomingPillType === this.requiredPillType) {
            this.pillEffectSequence(this.requiredPillType);
            this.setDamagePct(this._damagePercent - 0.04);
            this.app.fire('game::tintSpotsOnHand'); //Trigger white flicker only on correct matches.
        } else {
            this.pillEffectSequence('wrong');
        }
        entity.destroy();
        // const timeoutGameState = this.currentGameState;
        // setTimeout(() => {
        //     if (timeoutGameState === this.currentGameState) this.spawnNextTarget();
        // }, FEEDBACK_DURATION);
    }
    
    //this.app.fire('game::tintSpotsOnHand');
};

GameController.prototype.setDamagePct = function(pct) {
    this._damagePercent = pc.math.clamp(pct, 0.0, 1.0);
    this.uiDamageBarMask.element.width = this._damagePercent * this._damageBarMaskFullWidth; 
    
    var tweenR = pc.math.lerp(this.uiDamageBarFromColour.r, this.uiDamageBarToColour.r, this._damagePercent*2);
    var tweenG = pc.math.lerp(this.uiDamageBarFromColour.g, this.uiDamageBarToColour.g, this._damagePercent*2);
    var tweenB = pc.math.lerp(this.uiDamageBarFromColour.b, this.uiDamageBarToColour.b, this._damagePercent*2);
    this.uiDamageBarSprite.element.color = new pc.Color(tweenR, tweenG, tweenB);
    
    if (this.currentGameState === 11) { // Stage 1
        if (this._damagePercent > 0.5) {
            this.updateGameState(12);
        }
    }
    else if (this.currentGameState === 15) {
        if (this._damagePercent > 0.99 || this._damagePercent < 0.01) {
            this.updateGameState(16);
        }
    }
};

GameController.prototype.spawnNextTarget = function(handleDegradeEffect) {
    switch(this.currentGameState){
        case 11: // Stage 1 - Random cycle target
            var randArray = [0,1,2];
            const pillIdx = this.requiredPillTypes.indexOf(this.requiredPillType);
            if (pillIdx >= 0) {
                randArray.splice(pillIdx, 1);
            }
            this.requiredPillType = this.requiredPillTypes[randArray[Math.floor(pc.math.random(0,1)*randArray.length)]];
            break;
            
        case 13: // Stage 2 - Fixed sequenc B1 > B6 > B12, that will lead to Stage 3.
            var symptomIdx = this._stage2SpawnCount || 0;
            this.requiredPillType = null;
            if (symptomIdx < this.requiredPillTypes.length) {
                this.requiredPillType = this.requiredPillTypes[symptomIdx];
                this._stage2SpawnCount = symptomIdx + 1;
            } else {
                this.updateGameState(14);
            }
            break;
            
        case 15: // Stage 3 - All 3 targets spawns.
            this.stage3MultiTarget.enabled = true;
            this.degradeModelEffectAll.enabled = true;
            break;
    }
    
    this.targetB1Deficiency.enabled = false;
    this.targetB6Deficiency.enabled = false;
    this.targetB12Deficiency.enabled = false;
    
    this.degradeModelEffectB1.enabled = false;
    this.degradeModelEffectB6.enabled = false;
    this.degradeModelEffectB12.enabled = false;

    // Display entity.
    switch(this.requiredPillType){
        case 'b1':
            this.targetB1Deficiency.enabled = true;
            if (handleDegradeEffect) this.degradeModelEffectB1.enabled = true;
            break;

        case 'b6':
            this.targetB6Deficiency.enabled = true;
            if (handleDegradeEffect) this.degradeModelEffectB6.enabled = true;
            break;

        case 'b12':
            this.targetB12Deficiency.enabled = true;
            if (handleDegradeEffect) this.degradeModelEffectB12.enabled = true;
            break;
    }
};

GameController.prototype.spawnPills = function(isSpawnNbPill) {
    for (let i = 0; i < this.pillTypes.length; i += 1) {
        if (isSpawnNbPill && i < 3) {
            if (this.spawnedPills[i]) {
                this.spawnedPills[i].destroy();
                this.spawnedPills[i] = null;
            }
        } else if (!isSpawnNbPill && i < 3 && !this.spawnedPills[i] || isSpawnNbPill && i == 3 && !this.spawnedPills[i]) {
            var pillInstance = this.pillTemplateArray[i].resource.instantiate();
            this.spawnedPills[i] = pillInstance;
            this.app.root.addChild(pillInstance);
            
            var oPos = this.pillAnchorArray[i].getPosition();
            oPos.y -= 0.5;
            pillInstance.setPosition(oPos);
            
            this.pillTweens[i] = pillInstance
                .tween(pillInstance.getLocalPosition())
                .to(this.pillAnchorArray[i].getPosition(), 1, pc.QuadraticOut)
                .start();
        }
    }
};

GameController.prototype.spawnPillsState12 = function() {
    for (let i = 0; i < 3; i++) {
        // Spawn pill first and position.
        if (!this.spawnedPills[i]) {
            var pillInstance = this.pillTemplateArray[i].resource.instantiate();
            this.spawnedPills[i] = pillInstance;
            this.app.root.addChild(pillInstance);
            
            // turn off script on pill, prevent interaction.
            pillInstance.script.destroy('pillEntity');
            pillInstance.collision.enabled = false;
            pillInstance.rigidbody.enabled = false;
            
            let oPos = this.pillAnchorArray[i].getPosition();
            pillInstance.setPosition(oPos);
        }
        
        // Seq 1: Make 3 pills rise first.
        var tweenToPos = this.spawnedPills[i].getPosition();// + new pc.Vec3(0, 0, 0.04);
        tweenToPos.add(new pc.Vec3(0,0.03,0));
        var tweenRise;
        var durRise = 4;
        //var tweenSpin;
        
        //tweenSpin = this.spawnedPills[i].tween(this.spawnedPills[i].getLocalEulerAngles()).rotate({x: 0, y: 0, z: 0}, 2, pc.QuadraticInOut).start();
        tweenRise = this.spawnedPills[i].tween(this.spawnedPills[i].getLocalPosition())
            .to({x: tweenToPos.x, y: tweenToPos.y, z: tweenToPos.z}, durRise, pc.BackInOut)
            .start();
        
        // Seq 2: Make 3 pills float around, with manual delay.
        tweenToPos.add(new pc.Vec3(0,-0.015,0));
        var tweenFloat;
        var tweenSway;
        var durFloat = 2;
        var repFloat = 4;
        
        tweenSway = this.spawnedPills[i].tween(this.spawnedPills[i].getLocalEulerAngles()).rotate({x: -20, y: 0, z: 0}, durFloat, pc.QuadraticInOut).delay(2).start();
        tweenSway.yoyo(true).repeat(6);
        
        tweenFloat = this.spawnedPills[i].tween(this.spawnedPills[i].getLocalPosition().add(new pc.Vec3(0,0.03,0)))
            .to({x: tweenToPos.x, y: tweenToPos.y, z: tweenToPos.z}, durFloat, pc.QuadraticInOut)
            .delay(durRise).start();
        
        tweenFloat.yoyo(true).repeat(repFloat);
        
        // Seq 3: Now make them go towards NB spawn pt.
        var tweenNBpt = this.pillAnchorArray[3].getPosition().add(new pc.Vec3(0, 0.04, -0.04));
        var durCombine = 3;
        var tweenCombine;
        
        tweenCombine = this.spawnedPills[i].tween(this.spawnedPills[i].getLocalPosition())
            .to({x: tweenNBpt.x, y: tweenNBpt.y, z: tweenNBpt.z}, durCombine, pc.BackIn)
            .delay(durRise + durFloat*repFloat).start();
    }
    
    setTimeout(() => {
        
        var nbPillInstance = this.pillTemplateArray[3].resource.instantiate();
        
        // Hide NB Text first, show combination infographics.
        var titleNB = nbPillInstance.findOne('name', 'Text');
        titleNB.enabled = false;
        var infographics = nbPillInstance.findOne('name', 'infographics');
        infographics.enabled = true;
        
        this.spawnedPills[3] = nbPillInstance;
        this.app.root.addChild(nbPillInstance);
        let pos = this.pillAnchorArray[3].getPosition().add(new pc.Vec3(0, 0.04, -0.04));
        nbPillInstance.setPosition(pos);
        
        // Seq 4: Scale up spawned NB pill.
        var tweenScale;
        var durScale = 1;
        
        var data = {
            scaleTo: 0
        };
        
        var scaleAmount = 0.075;
        var scaleBase = nbPillInstance.getLocalScale().x;
        
        tweenScale = nbPillInstance.tween(data).to({scaleTo: 1}, durScale, pc.QuadraticInOut).start();
        tweenScale.on('update', function (dt) {
            var scaleCur = scaleBase + (scaleAmount * data.scaleTo);
            nbPillInstance.setLocalScale(scaleCur, scaleCur, scaleCur);
        }).on('complete', function(){
            
        });
        
        //Seq 5 Show NB Text.
        var tweenNBTitle;
        var scaleNBAmount = 0.02;
        var durNBScale = 0.5;
        var dataNBScale = {
            scaleTo: 0
        };
        var isFlipped = false;
        
        tweenNBTitle = titleNB.tween(data).to({scaleTo: 1}, durScale, pc.QuadraticInOut).delay(4).start();
        tweenNBTitle.on('update', function (dt) {
            if(!isFlipped){
                titleNB.enabled = true;
                infographics.enabled = false;
                //var pfxBlast = nbPillInstance.findOne('name', 'PFX Blast');
                //pfxBlast.particlesystem.play();
                isFlipped = true;
            }
            
            var s = 0.1 + scaleNBAmount * data.scaleTo;
            titleNB.setLocalScale(s, s, s);
        }).on('complete', function(){
        });
        tweenNBTitle.yoyo(true).repeat(2);
        
        
        // Seq 6: Scale back NB pill.
        tweenScale = nbPillInstance.tween(data).to({scaleTo: 1}, durScale, pc.BackOut).delay(durScale + 4.5).start().reverse();
        tweenScale.on('update', function (dt) {
            var scaleCur = scaleBase + (scaleAmount * data.scaleTo);
            nbPillInstance.setLocalScale(scaleCur, scaleCur, scaleCur);
        });
        
        // Finally, drop NB pill to ready position.
        var tweenReady;
        var posReady = this.pillAnchorArray[3].getPosition();
        var durReady = 3;
        
        this.spawnedPills[3]
            .tween(this.spawnedPills[3].getLocalPosition())
            .to(posReady, durReady, pc.BackOut)
            .delay(durScale*2 + 5)
            .start();
    }, 7500);
    
    // Kill 3 pills
    setTimeout(() => {
        for (let i = 0; i < 3; i += 1) {
            if (this.spawnedPills[i]) this.spawnedPills[i].destroy();
        }
    }, 7600);
    
};

// Added by Marcus, to spawn specific pills, for tutorial sections.
GameController.prototype.spawnPill = function(spawnArray) {
    for(var i = 0; i < spawnArray.length; i++){
        var pillInstance = this.pillTemplateArray[spawnArray[i]].resource.instantiate();
        this.spawnedPills[spawnArray[i]] = pillInstance;
        this.app.root.addChild(pillInstance);

        var oPos = this.pillAnchorArray[spawnArray[i]].getPosition();
        oPos.y -= 0.5;
        pillInstance.setPosition(oPos);
        
        this.pillTweens[i] = pillInstance
            .tween(pillInstance.getLocalPosition())
            .to(this.pillAnchorArray[spawnArray[i]].getPosition(), 1, pc.QuadraticOut)
            .start();   
    }
};

GameController.prototype.showSpawnedPills = function(isShow) {
    for(var i = 0; this.spawnedPills && i < this.spawnedPills.length; i++) {
        if ( this.spawnedPills[i]) {
             this.spawnedPills[i].enabled = isShow;
        }
    }
    // if (this.currentGameState == 11) {
    //     this.spawnPills(false);
    // } else if (this.currentGameState == 13 || this.currentGameState == 15) {
    //     this.spawnPills(true);
    // }
};

GameController.prototype.onTtsComplete = function(nextGameState) {
    switch(this.currentGameState){
        case 1: // ============================================== Vitamin B1 Intro
        case 3: // ============================================== Vitamin B1 Effect
        case 4: // ============================================== Vitamin B6 Intro
        case 6: // ============================================== Vitamin B6 Effect
        case 7: // ============================================== Vitamin B12 Intro
        case 9: // ============================================== Vitamin B12 Effect
        case 10: // ============================================== Game Commence
        case 12: // ============================================== Neurobion Intro 1
        case 14: // ============================================== Neurobion Intro 2
        case 16: // ============================================== Game Over / Game Won
            this.updateGameState(nextGameState);
            break;
    }
};

// Added by Marcus, main function to update game state
GameController.prototype.updateGameState = function(newGameState) {
    if (this.currentGameState > newGameState) return;
    
    // Update current game state.
    console.log("updateGameState", newGameState);
    this.currentGameState = newGameState;
    this.app.fire('progressIndicator', (this.currentGameState+16) / 34);
    
    var introB1 = this.IntroB1;
    var introB6 = this.IntroB6;
    var introB12 = this.IntroB12;
    
    var tutB1 = this.TutorialB1;
    var tutB6 = this.TutorialB6;
    var tutB12 = this.TutorialB12;
    
    var tgtB1 = this.targetB1Deficiency;
    var tgtB6 = this.targetB6Deficiency;
    var tgtB12 = this.targetB12Deficiency;
    
    var effectB1 = this.TutorialEffectB1;
    var effectB6 = this.TutorialEffectB6;
    var effectB12 = this.TutorialEffectB12;
    
    var gameCommence = this.etGameCommence;
    var gameEnd = this.etGameEnd;
    
    var curDmg = this.damagePt;
    
    switch(newGameState){
        case 1: // ============================================== Vitamin B1 Intro
            introB1.enabled = true;
            this.setDamagePct(0.5);
            this.degradeModelEffectB1.enabled = true;
            this.targetB1Deficiency.enabled = true;
            this.btnGameEnd.enabled = false;
            break;
            
        case 2: // ============================================== Vitamin B1 Tutorial
            introB1.enabled = false;
            tutB1.enabled = true;
            tgtB1.enabled = true;
            this.spawnPill([0]);// 0 = B1 from instantiate array
            break;
        
        case 3: // ============================================== Vitamin B1 Effect
            tutB1.enabled = false;
            tgtB1.enabled = false;
            
            this.setDamagePct(0.1);
            
            effectB1.enabled = true;
            this.degradeModelEffectB1.enabled = false;
            this.regenModelEffectB1.enabled = true;
            break;
            
        case 4: // ============================================== Vitamin B6 Intro
            effectB1.enabled = false;
            this.regenModelEffectB1.enabled = false;
            
            introB6.enabled = true;
            this.setDamagePct(0.5);
            this.degradeModelEffectB6.enabled = true;
            this.targetB6Deficiency.enabled = true;
            break;
            
        case 5: // ============================================== Vitamin B6 Tutorial
            introB6.enabled = false;
            tutB6.enabled = true;
            tgtB6.enabled = true;
            this.spawnPill([1]); // 1 = B6 from instantiate array
            break;
        
        case 6: // ============================================== Vitamin B6 Effect
            tutB6.enabled = false;
            tgtB6.enabled = false;
            
            this.setDamagePct(0.1);
            
            effectB6.enabled = true;
            this.degradeModelEffectB6.enabled = false;
            this.regenModelEffectB6.enabled = true;
            break;
            
        case 7: // ============================================== Vitamin B12 Intro
            this.setDamagePct(0.5);
            
            effectB6.enabled = false;
            this.regenModelEffectB6.enabled = false;
            
            introB12.enabled = true;
            this.degradeModelEffectB12.enabled = true;
            this.targetB12Deficiency.enabled = true;
            break;
            
        case 8: // ============================================== Vitamin B12 Tutorial
            introB12.enabled = false;
            
            tutB12.enabled = true;
            tgtB12.enabled = true;
            
            this.spawnPill([2]);  // 2 = B12 from instantiate array
            break;
            
        case 9: // ============================================== Vitamin B12 Effect
            tutB12.enabled = false;
            tgtB12.enabled = false;
            
            this.setDamagePct(0.1);
            
            effectB12.enabled = true;
            this.degradeModelEffectB12.enabled = false;
            this.regenModelEffectB12.enabled = true;
            break;
            
        case 10: // ============================================== Game Commence
            effectB12.enabled = false;
            this.regenModelEffectB12.enabled = false;
            this.etGameCommence.enabled = true;
            break;
            
        case 11: // ============================================== Stage 1
            this.etGameCommence.enabled = false;
            this.setDamagePct(0.0);
            this.spawnPills(false);
            this.spawnNextTarget(true);
            break;
                        
        case 12: // ============================================== Neurobion Intro 1
            this.spawnPillsState12();
            this.requiredPillType = null;
            this.spawnNextTarget();
            this.IntroNB1.enabled = true;
            break;
        
        case 13: // ============================================== Stage 2
            this._stage2SpawnCount = 0;
            this.IntroNB1.enabled = false;
            this.setDamagePct(0.5);
            this.spawnPills(true);
            this.spawnNextTarget(true);
            break;
        
        case 14: // ============================================== Neurobion Intro 2
            this.IntroNB2.enabled = true;
            break;
        
        case 15: // ============================================== Stage 3
            this.requiredPillType = null;
            this.setDamagePct(0.5);
            this.IntroNB2.enabled = false;
            this.stage3MultiTarget.enabled = true;
            for(let i = 0; i < this.stage3MultiHands.length; i += 1) {
                this.stage3MultiHands[i].enabled = true;
            }
            this.spawnPills(true);
            const btnGameEnd = this.btnGameEnd;
            setTimeout(() => {
                if (this.currentGameState === 15) btnGameEnd.enabled = true;
            }, 5000);
            break;
        
        case 16: // ============================================== Game Over
            this.uiEffectNB.enabled = false;
            this.regenModelEffectAll.enabled = false;
            this.stage3MultiTarget.enabled = false;
            
            for(let i = 0; i < this.stage3MultiHands.length; i += 1) {
                this.stage3MultiHands[i].enabled = false;
            }
            this.stage3MultiTarget.enable = false;
            for(var i = 0; i < this.spawnedPills.length; i++){
                if(this.spawnedPills[i] !== null){
                    this.spawnedPills[i].destroy();
                    this.spawnedPills[i] = null;
                }
            }
            if (this._damagePercent > 0.1) {
                this.uiGameOver.parent.enabled = true;
                this.uiGameOver.enabled = true;
            } else {
                this.uiGameWon.parent.enabled = true;
                this.uiGameWon.enabled = true;
            }
            this.btnGameEnd.enabled = false;
            break;
            
        case 17:
            this.uiEffectNB.enabled = false;
            this.regenModelEffectAll.enabled = false;
            this.stage3MultiTarget.enabled = false;
            
            for(let i = 0; i < this.stage3MultiHands.length; i += 1) {
                this.stage3MultiHands[i].enabled = false;
            }
            this.stage3MultiTarget.enable = false;
            for(var i = 0; i < this.spawnedPills.length; i++){
                if(this.spawnedPills[i] !== null){
                    this.spawnedPills[i].destroy();
                    this.spawnedPills[i] = null;
                }
            }
            this.btnGameEnd.enabled = false;

            this.uiGameOver.parent.enabled = false;
            this.uiGameOver.enabled = false;
            this.uiGameWon.parent.enabled = false;
            this.uiGameWon.enabled = false;
            this.app.fire('managerflow:allowTransition');
            break;
    }
};

const FEEDBACK_DURATION = 4000;
let prevEffectType;
let prevEffectTimeout;
let cam3DEffectTimeout;
GameController.prototype.pillEffectSequence = function(type) {
    
    // this.effectModelsParent.enabled = true;
    // if (cam3DEffectTimeout) {
    //     clearTimeout(cam3DEffectTimeout);
    // }
    // cam3DEffectTimeout = setTimeout(() => {
    //     this.effectModelsParent.enabled = false;
    // }, FEEDBACK_DURATION);
    
    this.uiEffectB1.enabled = type === 'b1';
    this.regenModelEffectB1.enabled = type === 'b1';
    this.uiEffectB6.enabled = type === 'b6';
    this.regenModelEffectB6.enabled = type === 'b6';
    this.uiEffectB12.enabled = type === 'b12';
    this.regenModelEffectB12.enabled = type === 'b12';
    this.uiEffectNB.enabled = type === 'nb';
    this.regenModelEffectAll.enabled = type === 'nb';
    this.uiEffectWrong.enabled = type === 'wrong';
    
    this.degradeModelEffectB1.enabled = false;
    this.degradeModelEffectB6.enabled = false;
    this.degradeModelEffectB12.enabled = false;
    this.degradeModelEffectAll.enabled = false;
    
    if (prevEffectType == type) {
        clearTimeout(prevEffectTimeout);
    }
    
    const gameController = this;
    
    prevEffectTimeout = setTimeout(() => {
        if (type === 'b1') this.uiEffectB1.enabled = false;
        if (type === 'b1') this.regenModelEffectB1.enabled = false;
        if (type === 'b6') this.uiEffectB6.enabled = false;
        if (type === 'b6') this.regenModelEffectB6.enabled = false;
        if (type === 'b12') this.uiEffectB12.enabled = false;
        if (type === 'b12') this.regenModelEffectB12.enabled = false;
        if (type === 'nb') this.uiEffectNB.enabled = false;
        if (type === 'nb') this.regenModelEffectAll.enabled = false;
        if (type === 'wrong') this.uiEffectWrong.enabled = false;
        
        switch(this.currentGameState){
            case 11: // Stage 1
                this.spawnPills(false);
                break;
            case 13: // Stage 2
                if (this._stage2SpawnCount < 3) this.spawnPills(true);
                break;
            case 15: // Stage 3
                this.spawnPills(true);
                break;
        }
        
        this.spawnNextTarget(true);
        prevEffectTimeout = 0;
    }, FEEDBACK_DURATION);
    prevEffectType = type;
};

GameController.prototype.initialisePillSpawnAnchors = function() {
    this.pillAnchorArray = [this.b1PillAnchor, this.b6PillAnchor, this.b12PillAnchor, this.nbPillAnchor];
    // console.log(window.innerHeight, window.innerWidth, window.innerHeight / window.innerWidth);
    // const pos = this.cameraEntity.camera.screenToWorld(0,  window.innerHeight, -0.145);
    // this.b1PillAnchor.setPosition(pos.x, pos.y, pos.z);
    // const worldPos = this.cameraEntity.camera.screenToWorld(0, window.innerHeight, this.cameraEntity.camera.nearClip);
    // for (let i = 0; i < this.pillAnchorArray.length; i += 1) {
    //     const curPos = this.pillAnchorArray[i].getPosition();
    //     this.pillAnchorArray[i].setPosition(curPos.x, worldPos.y, curPos.z);
    // }
};
