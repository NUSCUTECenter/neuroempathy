var TweenAnimation = pc.createScript('tweenAnimation');

TweenAnimation.attributes.add( 'targetEntity', { type: 'entity' } );

TweenAnimation.prototype.initialize = function() {
    this.onStateChanged(true);
    this.on('state', this.onStateChanged, this);
};

TweenAnimation.prototype.onStateChanged = function(enabled) {
    if (enabled) {
        const entity = this.targetEntity || this.entity;
        const animationAssets = entity.animation.assets;
        if (!animationAssets.length) return;
        const animationName = entity.animation.animationsIndex[animationAssets[0]];
        setTimeout(() => entity.animation.play(animationName, 0), 0);
        entity.animation.play(animationName, 0);
        entity.animation.currentTime = 0;
        
    } else {
        const entity = this.targetEntity || this.entity;
        entity.animation.currentTime = 0;
    }
};