var TweenTint = pc.createScript('tweenTint');

TweenTint.attributes.add( 'targetEntity', { type: 'entity' } );
TweenTint.attributes.add( 'materialIdx', { type: 'number', default: 0 } );
TweenTint.attributes.add( 'fromColour', { type: 'rgb', default: [1, 1, 1], title: 'Tint Color' } );
TweenTint.attributes.add( 'toColour', { type: 'rgb', default: [1, 1, 1], title: 'Tint Color' } );
TweenTint.attributes.add('curveColour', { type: 'curve' });
TweenTint.attributes.add('curveAlpha', { type: 'curve' }); 
TweenTint.attributes.add('duration', { type: 'number', default: 2.0 }); 

TweenTint.prototype.initialize = function() {
    this.onEnable();
    this.entity.on('enable', this.onEnable, this);
};

TweenTint.prototype.onEnable = function() {
    var tweenData = { value: 0 };
    var fromColour = this.fromColour;
    var toColour = this.toColour;
    var curveColour = this.curveColour;
    var curveAlpha = this.curveAlpha;
    var material = (this.targetEntity || this.entity).model.model.meshInstances[this.materialIdx].material;
    
    this.app.tween(tweenData)
    .to({ value: 1.0 }, this.duration, pc.Linear)
    .on('update', function(dt) {
        var tweenValue = tweenData.value;
        var curveColourValue = curveColour.value(tweenValue);
        var tweenR = pc.math.lerp(fromColour.r, toColour.r, curveColourValue);
        var tweenG = pc.math.lerp(fromColour.g, toColour.g, curveColourValue);
        var tweenB = pc.math.lerp(fromColour.b, toColour.b, curveColourValue);
        var curveAlphaValue = curveAlpha.value(tweenValue);

        material.diffuse.set(tweenR, tweenG, tweenB);
        material.opacity = curveAlphaValue;
        material.update();
    })
    .loop(false)
    .yoyo(false)
    .start();
};
