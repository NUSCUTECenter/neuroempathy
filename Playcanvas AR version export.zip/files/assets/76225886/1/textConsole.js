var TextConsole = pc.createScript('textConsole');

TextConsole.attributes.add('eText', {
    type: 'entity'
});

TextConsole.attributes.add('letterSpeed', {
    type: 'number',
    default: 60
});

TextConsole.attributes.add('bLoop', {
    type: 'boolean',
    default: false
});

TextConsole.attributes.add('initialDelay', {
    type: 'number',
    default: 500
});

var typewriter;
var stringToType;

// initialize code called once per entity
TextConsole.prototype.initialize = function() {
    var app = document.getElementById('app');
    var txt = this.eText;
    var isLoop = this.bLoop;
    var speed = this.letterSpeed;
    var initDelay = this.initialDelay;
    
    stringToType = txt.element.text;
    txt.element.text = "";
    
    var customNodeCreator = function(character) {
        // Add character to input placeholder
        var curText = txt.element.text;
        curText += character;
        txt.element.text = curText;

        // Return null to skip internal adding of dom node
        return null;
    };
    
    var onRemoveNode = function({ character }) {
        var curText = txt.element.text;
        curText = curText.slice(0, -1);
        txt.element.text = curText;
    };
    
    typewriter = new Typewriter(app, {
        loop: isLoop,
        delay: speed,
        onCreateTextNode: customNodeCreator,
        onRemoveNode: onRemoveNode,
    });
    
    typewriter
        .pauseFor(initDelay)
        .typeString(stringToType)
        .callFunction(() => {
        
      })
      .start();
    
};
