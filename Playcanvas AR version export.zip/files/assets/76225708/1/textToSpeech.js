var TextTospeech = pc.createScript('textTospeech');

TextTospeech.attributes.add('tts', {type: 'string'});
TextTospeech.attributes.add('willFireOnEnd', {type: 'boolean', default: false});
TextTospeech.attributes.add('fireCommand', {type: 'string'});
TextTospeech.attributes.add('fireCommandPara', {type: 'number'});
TextTospeech.attributes.add('fireCommandTimeout', {type: 'number'});

TextTospeech.prototype.initialize = function() {
    this.isTriggered = false;
    
    this.triggerTTS();
    
    this.on('enable', function () {
        this.triggerTTS();
    });
    
    this.on('disable', function () {
    });
};

TextTospeech.prototype.triggerTTS = function (event) 
{
    if (this.isTriggered) return;
    this.isTriggered = true;
    
    var t = this.tts;
    var bEndFire = this.willFireOnEnd;
    var fc = this.fireCommand;
    var fcp = this.fireCommandPara;
    var self = this;
    
    var mytimer = setInterval(function() 
    {
        let isFired = false;
        var voices = speechSynthesis.getVoices();
        //console.log(voices);
        if (voices.length !== 0) 
        {
            var msg = new SpeechSynthesisUtterance();

            msg.rate = 1.0; // 0.1 to 10
            msg.pitch = 1.0; //0 to 2
            msg.volume = 1.0; // 0 to 1

            msg.text = t;
            msg.lang =  'en'; //'hi-IN';

            for(var i=0;i<voices.length;i++)
            {
                //console.log(voices[i].name);
                if(voices[i].name === "Microsoft David - English (United States)") 
                {
                  msg.voice = voices[i]; // Note: some voices don't support altering params
                  msg.voiceURI = voices[i].voiceURI;
              // break;
                }
            }
            
            if(bEndFire) {
                msg.onend = function(e) {
                    if (!isFired) {
                        isFired = true;
                        console.log('onend fire', fcp);
                        self.app.fire(fc, fcp);
                    }
                };
                
                 setTimeout(function(e) {
                     // console.log('timeout', fcp, this.lastFired);
                     if (!isFired) {
                         isFired = true;
                         console.log('timeout fire', fcp);
                         self.app.fire(fc, fcp);
                     }
                 }, 10000);
            }
            
        speechSynthesis.cancel();
        speechSynthesis.speak(msg);

        clearInterval(mytimer);

        }
    }, 500);
};