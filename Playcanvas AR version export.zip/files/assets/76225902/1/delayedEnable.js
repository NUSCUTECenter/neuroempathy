var DelayedEnable = pc.createScript('delayedEnable');

DelayedEnable.attributes.add('entity1', {type: 'entity'});
DelayedEnable.attributes.add('entity2', {type: 'entity'});
DelayedEnable.attributes.add('delay', {type: 'number'});

DelayedEnable.prototype.initialize = function() {
    const entity1 = this.entity1;
    const entity2 = this.entity2;
    const delay = this.delay;

    let timeout;

    const onEnable = () => {
        if (entity1) entity1.enabled = true;
        if (entity2) entity2.enabled = false;

        timeout = setTimeout(() => {
            if (entity1) entity1.enabled = false;
            if (entity2) entity2.enabled = true;
        }, delay * 1000);
    };

    this.on('enable', onEnable);

    this.on('disable', function () {
        clearTimeout(timeout);
    });

    onEnable();
};

