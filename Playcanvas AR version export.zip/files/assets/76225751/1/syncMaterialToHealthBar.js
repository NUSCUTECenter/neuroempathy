var SyncMaterialTohealthBar = pc.createScript('syncMaterialTohealthBar');

SyncMaterialTohealthBar.attributes.add( 'targetEntity', { type: 'entity' } );
SyncMaterialTohealthBar.attributes.add( 'materialIdx', { type: 'number', array: true } );
SyncMaterialTohealthBar.attributes.add('uiDamageBarFromColour', { type: 'rgb', default: [1, 1, 1] } );
SyncMaterialTohealthBar.attributes.add('uiDamageBarToColour', { type: 'rgb', default: [1, 1, 1] } );

// update code called every frame
SyncMaterialTohealthBar.prototype.update = function(dt) {
    const pct = this.app.gameController._damagePercent;
    var tweenR = pc.math.lerp(this.uiDamageBarFromColour.r, this.uiDamageBarToColour.r, pct*2);
    var tweenG = pc.math.lerp(this.uiDamageBarFromColour.g, this.uiDamageBarToColour.g, pct*2);
    var tweenB = pc.math.lerp(this.uiDamageBarFromColour.b, this.uiDamageBarToColour.b, pct*2);
    const targetEntity = this.targetEntity || this.entity;
    this.materialIdx.forEach(idx => {
        var material = targetEntity.model.model.meshInstances[idx].material;
        material.diffuse.set(tweenR, tweenG, tweenB);
        material.update();
    });
};
