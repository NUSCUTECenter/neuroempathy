var BleSend = pc.createScript('bleSend');

BleSend.prototype.initialize = function() {
    this.dtInterval = 0;
    const app = this.app;

    this.on('disable', function () {
        let repeats = 0;
        const send = () => {
            if (app.ble && app.ble.characteristics && app.ble.characteristics[0]) {
                app.ble.write(app.ble.characteristics[0], '0');
                console.log('bleSend', 0);
            }
        };
        send();
        setTimeout(send, 500);
        setTimeout(send, 1000);
        setTimeout(send, 1500);
    });
};

BleSend.prototype.update = function(dt) {
    this.dtInterval += dt;
    if (this.dtInterval >= 0.5) {
        this.dtInterval -= 0.5;
        if (this.app.ble && this.app.ble.characteristics && this.app.ble.characteristics[0]) {
            this.app.ble.write(this.app.ble.characteristics[0], '3');
        }
    }
};
