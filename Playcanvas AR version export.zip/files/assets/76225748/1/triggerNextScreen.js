var TriggerNextScreen = pc.createScript('triggerNextScreen');

// initialize code called once per entity
TriggerNextScreen.prototype.initialize = function() {
    this.entity.element.on('click', function(event) {
        this.app.fire('managerflow:allowTransition');
    }, this);
};
