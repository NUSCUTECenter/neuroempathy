var MouseMoveScaleRotate = pc.createScript('mouseMoveScaleRotate');

MouseMoveScaleRotate.attributes.add('cameraEntity', {type: 'entity', title: 'Camera Entity'});
MouseMoveScaleRotate.attributes.add('orbitSensitivity', {
    type: 'number', 
    default: 0.3, 
    title: 'Orbit Sensitivity', 
    description: 'How fast the camera moves around the orbit. Higher is faster'
});
MouseMoveScaleRotate.attributes.add('moveSensitivity', {
    type: 'number', 
    default: 0.004, 
});
MouseMoveScaleRotate.attributes.add('scaleSensitivity', {
    type: 'number', 
    default: 0.00005, 
});


// initialize code called once per entity
MouseMoveScaleRotate.prototype.initialize = function() {
    this.app.mouse.on(pc.EVENT_MOUSEMOVE, this.onMouseMove, this);
    
    this.lastTouchPoint = new pc.Vec2();
    this.lastTouchPoint2 = new pc.Vec2();
    if (this.app.touch) {
        this.app.touch.on(pc.EVENT_TOUCHSTART, this.onTouchStart, this);
        this.app.touch.on(pc.EVENT_TOUCHMOVE, this.onTouchMove, this);
        this.app.touch.on(pc.EVENT_TOUCHEND, this.onTouchEnd, this);
        this.app.touch.on(pc.EVENT_TOUCHCANCEL, this.onTouchCancel, this);
    } else {
        this.app.mouse.on(pc.EVENT_MOUSEDOWN, this.onMouseDown, this);
        this.app.mouse.on(pc.EVENT_MOUSEMOVE, this.onMouseMove, this);
        this.app.mouse.on(pc.EVENT_MOUSEUP, this.onMouseUp, this);
    }
    
    this.initialRot = this.entity.getLocalRotation().clone();
    this.initialScale = this.entity.getLocalScale().clone();
    this.initialPos = this.entity.getLocalPosition().clone();
    
    // this.on('enable', this.onEnable, this);
    this.on('state', this.onEnable, this);
    // this.onEnable();
};

MouseMoveScaleRotate.prototype.onEnable = function (event) {
    if (true) {
        MouseMoveScaleRotate.horizontalQuat = new pc.Quat();
        MouseMoveScaleRotate.verticalQuat = new pc.Quat();
        MouseMoveScaleRotate.resultQuat = new pc.Quat();
        this.entity.setLocalRotation(this.initialRot);
        this.entity.setLocalPosition(this.initialPos);
        this.entity.setLocalScale(this.initialScale);
    }
};

MouseMoveScaleRotate.horizontalQuat = new pc.Quat();
MouseMoveScaleRotate.verticalQuat = new pc.Quat();
MouseMoveScaleRotate.resultQuat = new pc.Quat();

MouseMoveScaleRotate.prototype.rotate = function (dx, dy) {
    var horzQuat = MouseMoveScaleRotate.horizontalQuat;
    var vertQuat = MouseMoveScaleRotate.verticalQuat;
    var resultQuat = MouseMoveScaleRotate.resultQuat;

    // Create a rotation around the camera's orientation in order for them to be in 
    // screen space  
    horzQuat.setFromAxisAngle(this.cameraEntity.up, dx * this.orbitSensitivity);
    vertQuat.setFromAxisAngle(this.cameraEntity.right, dy * this.orbitSensitivity);

    // Apply both the rotations to the existing entity rotation
    resultQuat.mul2(horzQuat, vertQuat);
    resultQuat.mul(this.entity.getRotation());

    this.entity.setRotation(resultQuat);    
};

MouseMoveScaleRotate.prototype.move = function (dx, dy) {
    const pos = this.entity.getPosition();
    pos.x += this.moveSensitivity * dx;
    pos.y += this.moveSensitivity * -dy;
    this.entity.setLocalPosition(pos);
};

MouseMoveScaleRotate.prototype.scale = function (d) {
    const scale = this.entity.getLocalScale();
    scale.x = pc.math.clamp(scale.x + this.scaleSensitivity * d, 0.5, 3);
    scale.y = pc.math.clamp(scale.x + this.scaleSensitivity * d, 0.5, 3);
    scale.z = pc.math.clamp(scale.x + this.scaleSensitivity * d, 0.5, 3);
    this.entity.setLocalScale(scale);
};

MouseMoveScaleRotate.prototype.onTouchStart = function (event) {
    if (event.touches.length > 0) {
        var touch = event.touches[0];
        this.lastTouchPoint.set(touch.x, touch.y);
        this.checkIfIsTouched(touch.x, touch.y);
    }
    event.event.preventDefault();
};

MouseMoveScaleRotate.prototype.onTouchMove = function (event) {
    var touch = event.touches[0];
    var dx = touch.x - this.lastTouchPoint.x;
    var dy = touch.y - this.lastTouchPoint.y;
    
    if (event.touches.length == 1) {
        if (event.touches.length == this.prevTouchCount && this.isTouched) this.rotate(dx, dy);
        this.lastArea = 0;
    } else if (event.touches.length == 2) {
        // this.move(dx, dy);
        
        var touch2 = event.touches[1];
        var lengthX = Math.abs(touch2.x - touch.x);
        var lengthY = Math.abs(touch2.y - touch.y);
        var area = lengthX * lengthY;
        if (this.lastArea > 0) {
            var dArea = area - this.lastArea;
            this.scale(dArea);
        }
        this.lastArea = area;
    }
    
    this.onTouchStart(event);
    this.prevTouchCount = event.touches.length;
    event.event.preventDefault();
};

MouseMoveScaleRotate.prototype.onTouchEnd = function (event) {
    this.isTouched = false;
    this.lastArea = 0;
    event.event.preventDefault();
};

MouseMoveScaleRotate.prototype.onMouseDown = function(event) {
    this.checkIfIsTouched(event.x, event.y);
};

MouseMoveScaleRotate.prototype.onMouseMove = function (event) {    
    var mouse = this.app.mouse;
    if (mouse.isPressed(pc.MOUSEBUTTON_LEFT)) {
        // this.move(event.dx, event.dy);
        // if (this.isTouched) 
        this.rotate(event.dx, event.dy);
        // this.scale(event.dx);
    }
    
    event.event.preventDefault();
};

MouseMoveScaleRotate.prototype.onMouseUp = function(event) {
    this.isTouched = false;
    event.event.preventDefault();
};

MouseMoveScaleRotate.prototype.checkIfIsTouched = function(x, y) {
    const from = this.cameraEntity.camera.screenToWorld(x, y, this.cameraEntity.camera.nearClip);
    const to = this.cameraEntity.camera.screenToWorld(x, y, this.cameraEntity.camera.farClip);

    // const result = this.app.systems.rigidbody.raycastFirst(from, to);
    // if (result && result.entity === this.entity) {
        this.isTouched = true;
    // }
};