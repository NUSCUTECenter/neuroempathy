var TweenMoveLocal = pc.createScript('tweenMoveLocal');



TweenMoveLocal.attributes.add('moveFrom', {
    type: 'vec3'
});

TweenMoveLocal.attributes.add('moveTo', {
    type: 'vec3'
});

TweenMoveLocal.attributes.add('moveSpeed', {
    type: 'number',
    default: 1.0
});

TweenMoveLocal.attributes.add('initDelay', {
    type: 'number',
    default: 0
});

TweenMoveLocal.attributes.add('easing', {
    type: 'string',
    default: "pc.Linear",
    enum: [
        { 'Linear': "pc.Linear" },
        { 'QuadIn': "pc.QuadraticIn" },
        { 'QuadOut': "pc.QuadraticOut" },
        { 'QuadInOut': "pc.QuadraticInOut" },
        { 'CubicIn': "pc.CubicIn" },
        { 'CubicOut': "pc.CubicOut" },
        { 'CubicInOut': "pc.CubicInOut" },
        { 'QuarticIn': "pc.QuarticIn" },
        { 'QuarticOut': "pc.QuarticOut" },
        { 'QuarticInOut': "pc.QuarticInOut" },
        { 'QuinticIn': "pc.QuinticIn" },
        { 'QuinticOut': "pc.QuinticOut" },
        { 'QuinticInOut': "pc.QuinticInOut" },
        { 'SineIn': "pc.SineIn" },
        { 'SineOut': "pc.SineOut" },
        { 'SineInOut': "pc.SineInOut" },
        { 'ExponentialIn': "pc.ExponentialIn" },
        { 'ExponentialOut': "pc.ExponentialOut" },
        { 'ExponentialInOut': "pc.ExponentialInOut" },
        { 'CircularIn': "pc.CircularIn" },
        { 'CircularOut': "pc.CircularOut" },
        { 'CircularInOut': "pc.CircularInOut" },
        { 'BackIn': "pc.BackIn" },
        { 'BackOut': "pc.BackOut" },
        { 'BackInOut': "pc.BackInOut" },
        { 'BounceIn': "pc.BounceIn" },
        { 'BounceOut': "pc.BounceOut" },
        { 'BounceInOut': "pc.BounceInOut" },
        { 'ElasticIn': "pc.ElasticIn" },
        { 'ElasticOut': "pc.ElasticOut" },
        { 'ElasticInOut': "pc.ElasticInOut" }
    ]
});

TweenMoveLocal.attributes.add('bLoop', {
    type: 'boolean',
    default: false
});

TweenMoveLocal.attributes.add('bYoyoInfinite', {
    type: 'boolean',
    default: false
});

TweenMoveLocal.attributes.add('bYoyo', {
    type: 'boolean',
    default: false,
    title: 'Will it reverse?'
});

TweenMoveLocal.attributes.add('delayYoyo', {
    type: 'number',
    default: 0,
    title: 'Delay before yoyo [in ms]'
});

// initialize code called once per entity
TweenMoveLocal.prototype.initialize = function() {
    this.enter();
    
    this.on('enable', function () {
        this.enter();
    }, this);
    
    this.on('disable', function () {
        var mFr = this.moveFrom;
        this.entity.setLocalPosition(mFr.x, mFr.y, mFr.z);
    }, this);
};


TweenMoveLocal.prototype.enter = function() {
    var self = this;
    var mTo = self.moveTo;
    var mFr = self.moveFrom;
    var speed = self.moveSpeed;
    var iDelay = self.initDelay;
    var bloop = self.bLoop;
    var byoyo = self.bYoyo;
    var easing = self.easing;
    var delayYoyo = self.delayYoyo;
    var bYoyoInfinite = self.bYoyoInfinite;
    var tween;
    
    self.entity.setLocalPosition(mFr.x, mFr.y, mFr.z);
    
    tween = self.entity.tween(self.entity.getLocalPosition()).to({x: mTo.x, y: mTo.y, z: mTo.z}, speed, pc[easing]).delay(iDelay);
    tween.loop(bloop);
    //tween.yoyo(byoyo).repeat(2);
    
    if(bYoyoInfinite){
        tween.yoyo(true).repeat(9999);
    }
    
    tween.on('complete', function () {
       if(byoyo){
            setTimeout(function(){
                self.tweenExit();
            },delayYoyo);
        }
    });
    
    tween.start();
};

TweenMoveLocal.prototype.tweenExit = function() {
    var self = this;
    var mTo = self.moveTo;
    var mFr = self.moveFrom;
    var speed = self.moveSpeed;
    var tween;
    
    self.entity.setLocalPosition(mTo.x, mTo.y, mTo.z);
    
    tween = self.entity.tween(self.entity.getLocalPosition()).to({x: mFr.x, y: mFr.y, z: mFr.z}, speed, pc.SineOut);
    tween.start();
};