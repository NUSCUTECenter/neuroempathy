var Pill = pc.createScript('pill');


Pill.attributes.add('cam', {
    type: 'entity',
});

var isDragging = false;
var hitPosition = new pc.Vec3();
var dragPosition = new pc.Vec3();
var oriPosX;
var oriPosY;
var oriPosZ;

// initialize code called once per entity
Pill.prototype.initialize = function() {
    this.app.mouse.on(pc.EVENT_MOUSEDOWN, this.onSelect, this);
    this.app.mouse.on(pc.EVENT_MOUSEMOVE, this.onMove, this);
    this.app.mouse.on(pc.EVENT_MOUSEUP, this.onRelease, this);
    
    
    this.ray = new pc.Ray();
    // More information about pc.Plane: https://github.com/playcanvas/engine/blob/master/src/shape/plane.js
    this.plane = new pc.Plane(this.entity.getPosition().clone(), this.entity.forward.clone());
    
    oriPosX = this.entity.getLocalPosition().x;
    oriPosY = this.entity.getLocalPosition().y;
    oriPosZ = this.entity.getLocalPosition().z;
};


Pill.prototype.doRayCast = function (screenPosition) {
    var cam = this.cam;
    
    // Initialise the ray and work out the direction of the ray from the a screen position
    cam.camera.screenToWorld(screenPosition.x, screenPosition.y, cam.camera.farClip, this.ray.direction); 
    this.ray.origin.copy(cam.getPosition());
    this.ray.direction.sub(this.ray.origin).normalize();
    
    var interesecting = this.plane.intersectsRay(this.ray, hitPosition);        
    if (interesecting) {
        // Work out the vector from the box to the hitPosition
        dragPosition.sub2(hitPosition, this.entity.getPosition());
        
        // Project that vector on to the object's forward axis
        //dragPosition.project(new pc.Vec3(1,0,1));
        
        // Now move the object by that amount
        dragPosition.add(this.entity.getPosition());        
        this.entity.setPosition(dragPosition);
    }  
};

Pill.prototype.update = function(dt) {
    
};

Pill.prototype.onRelease = function (e) {
    isDragging = false;
    
    var cPos = this.entity.getLocalPosition();
    var oPos = new pc.Vec3(oriPosX, oriPosY, oriPosZ);
    var mag = oPos.distance(cPos);
    //console.log(mag);
    if(mag > 0.02){
        
    }else{
        this.entity
            .tween(cPos)
            .to(new pc.Vec3(oriPosX,oriPosY,oriPosZ), 0.5, pc.BounceOut)
            .start();
    }
};

Pill.prototype.onMove = function (e) {
    if(isDragging){
        this.doRayCast(e);
        
    }
};


Pill.prototype.onSelect = function (e) {
    var cam = this.cam;
    
    var from = cam.camera.screenToWorld(e.x, e.y, cam.camera.nearClip);
    var to = cam.camera.screenToWorld(e.x, e.y,cam.camera.farClip);

    var result = this.app.systems.rigidbody.raycastFirst(from, to);
    if (result) {
        var pickedEntity = result.entity;
        if(pickedEntity === this.entity){
            //console.log("hit self");
            isDragging = true;
        }
    }
};