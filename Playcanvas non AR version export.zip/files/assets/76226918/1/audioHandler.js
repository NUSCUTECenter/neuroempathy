var AudioHandler = pc.createScript('audioHandler');

AudioHandler.attributes.add('audioClipName', {type: 'string', default: 'Slot 1'});
AudioHandler.attributes.add('fireCommand', {type: 'string'});
AudioHandler.attributes.add('fireCommandPara', {type: 'number'});
AudioHandler.attributes.add('enableEntity', {type: 'entity' });
AudioHandler.attributes.add('manualDelay', {type: 'number' });

AudioHandler.prototype.initialize = function() {
    var fireCommand = this.fireCommand;
    var fireCommandPara = this.fireCommandPara;
    var app = this.app;
    var enableEntity = this.enableEntity;
    var manualDelay = this.manualDelay;
    
    if (enableEntity) enableEntity.enabled = false;
    
    if (manualDelay) {
        setTimeout(() => {
            if (fireCommand) app.fire(fireCommand, fireCommandPara);
            if (enableEntity) enableEntity.enabled = true;
        }, manualDelay * 1000);
    } else {
        this.entity.sound.on('end', () => {
            if (fireCommand) app.fire(fireCommand, fireCommandPara);
            if (enableEntity) enableEntity.enabled = true;
        });
    }
    
    this.on('enable', this.onEnable, this);
    this.onEnable();
};

AudioHandler.prototype.onEnable = function (event) {
    this.entity.sound.play(this.audioClipName);
    
};
