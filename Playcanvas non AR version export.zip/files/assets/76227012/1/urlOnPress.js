var UrlOnpress = pc.createScript('urlOnpress');

UrlOnpress.attributes.add('url', {type: 'string'});

UrlOnpress.prototype.initialize = function() {
    this.entity.element.on('click', function(event) {
        window.open(this.url);
    }, this);
};

// swap method called for script hot-reloading
// inherit your script state here
// UrlOnpress.prototype.swap = function(old) { };

// to learn more about script anatomy, please read:
// https://developer.playcanvas.com/en/user-manual/scripting/