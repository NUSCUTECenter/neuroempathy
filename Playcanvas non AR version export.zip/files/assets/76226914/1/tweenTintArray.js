var TweenTintArray = pc.createScript('tweenTintArray');

TweenTintArray.attributes.add('tweens', {
    type: 'json',
    array: true,
    schema: [{
        name: 'targetEntity',
        type: 'entity'
    },{
        name: 'materialIdx',
        type: 'number',
        default: 0
    },{
        name: 'fromColour',
        type: 'rgb',
        default: [1, 1, 1]
    },{
        name: 'toColour',
        type: 'rgb',
        default: [1, 1, 1]
    },{
        name: 'curveColour',
        type: 'curve',
    },{
        name: 'curveAlpha',
        type: 'curve',
    },{
        name: 'duration',
        type: 'number',
        default: 2.0
    },{
        name: 'loop',
        type: 'boolean',
        default: false
    },]
});

TweenTintArray.attributes.add('resetOnDisable', {
    type: 'boolean',
    default: true,
});

TweenTintArray.prototype.initialize = function() {
    this.startedTweensArr = [];
    this.tweens.forEach(tween => {
        var entity = tween.targetEntity || this.entity;
        if (!entity) return;
        var material = entity.model.model.meshInstances[tween.materialIdx].material;
        tween.initialColor = material.diffuse;
        tween.initialOpacity = material.opacity;
        tween.value = 0;
        
        var fromColour = tween.fromColour;
        var toColour = tween.toColour;
        var curveColourValue = tween.curveColour.value(0);
        var tweenR = pc.math.lerp(fromColour.r, toColour.r, curveColourValue);
        var tweenG = pc.math.lerp(fromColour.g, toColour.g, curveColourValue);
        var tweenB = pc.math.lerp(fromColour.b, toColour.b, curveColourValue);
        var curveAlphaValue = tween.curveAlpha.value(0);
        material.diffuse.set(tweenR, tweenG, tweenB);
        material.opacity = curveAlphaValue;
        material.update();
    });
    
    this.onStateChanged(true);
    this.on('state', this.onStateChanged, this);
};

TweenTintArray.prototype.onStateChanged = function(enabled) {
    if (enabled) {
        this.startedTweensArr = [];
        this.tweens.forEach(tween => {
            tween.value = 0;
            var fromColour = tween.fromColour;
            var toColour = tween.toColour;
            var curveColour = tween.curveColour;
            var curveAlpha = tween.curveAlpha;
            var loop = tween.loop;
            var entity = tween.targetEntity || this.entity;
            if (!entity) return;
            var material = entity.model.model.meshInstances[tween.materialIdx].material;

            var newTween = this.app.tween(tween)
            .to({ value: 1.0 }, tween.duration, pc.Linear)
            .on('update', function(dt) {
                var tweenValue = tween.value;
                var curveColourValue = curveColour.value(tweenValue);
                var tweenR = pc.math.lerp(fromColour.r, toColour.r, curveColourValue);
                var tweenG = pc.math.lerp(fromColour.g, toColour.g, curveColourValue);
                var tweenB = pc.math.lerp(fromColour.b, toColour.b, curveColourValue);
                var curveAlphaValue = curveAlpha.value(tweenValue);

                material.diffuse.set(tweenR, tweenG, tweenB);
                material.opacity = curveAlphaValue;
                material.update();
            })
            .loop(loop)
            .start();
             this.startedTweensArr.push(newTween);
        });
    } else {
        this.startedTweensArr.forEach(tween => {
            tween.loop(false).stop();
            tween.value = 0;
        });
        if (this.resetOnDisable) {
            this.tweens.forEach(tween => {
                var entity = tween.targetEntity || this.entity;
                if (!entity) return;
                 var material = entity.model.model.meshInstances[tween.materialIdx].material;
                 if (tween.initialColor) material.diffuse.set(tween.initialColor.r, tween.initialColor.g, tween.initialColor.b);
                 if (tween.initialOpacity) material.opacity = tween.initialOpacity;
                 material.update();
            });
        }
    }
};