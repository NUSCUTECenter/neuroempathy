var ManagerFlow = pc.createScript('managerFlow');

ManagerFlow.attributes.add('backElementEntity', {
    type: 'entity'
});

ManagerFlow.attributes.add('arCamera', {
    type: 'entity',
});

ManagerFlow.attributes.add('bgCamera', {
    type: 'entity',
});

ManagerFlow.attributes.add('screens', {
    type: 'entity',
    array: true
});

ManagerFlow.attributes.add('screenModels', {
    type: 'entity',
    array: true
});


ManagerFlow.attributes.add('pfxZoom', {
    type: 'entity',
});

ManagerFlow.attributes.add('audioSFX', {
    type: 'entity',
});
ManagerFlow.attributes.add('audioBGM', {
    type: 'entity',
});

var currentScreenID = 0;

// initialize code called once per entity
ManagerFlow.prototype.initialize = function() {
    // Can be called by any scripts to allow interaction to transition to next screen.
    this.app.on('managerflow:allowTransition', this.goToNextScreen, this);

    var allscreens = this.screens;
    var allmodels = this.screenModels;
    
    for(var i = 0; i < allscreens.length; i++){
        if (allscreens[i].enabled) {
            currentScreenID = i;
        }
        allscreens[i].enabled = false;
        allmodels[i].enabled = false;
    }

    for(var j = 0; j < allscreens.length; j++){
        allscreens[j].enabled = currentScreenID == j;
        allmodels[j].enabled = currentScreenID == j;
   }

     this.backElementEntity.enabled = currentScreenID > 0 && currentScreenID < 14 || currentScreenID == 15;
     this.backElementEntity.element.on('click', function(event) {
         if (currentScreenID == 15) {
            allscreens[currentScreenID].enabled = false;
            allmodels[currentScreenID].enabled = false;
            currentScreenID = 1;
            this.goToNextScreen(true);
         } else {
            this.goToNextScreen(false);
         }
     }, this);
};

ManagerFlow.prototype.goToNextScreen = function(isNext = true) {
    var allscreens = this.screens;
    var allmodels = this.screenModels;
    var sfx = this.audioSFX;
    var bgm = this.audioBGM;
    
    if(!bgm.sound.isPlaying){
        bgm.sound.play("bgmA");
    }

    if(currentScreenID < allscreens.length - 1){
        // SFX
        if (isNext && ![1,2,3,4,5,10,14].includes(currentScreenID)) sfx.sound.play("dingA");
        // if (isNext && !this.app.ble) this.startBLE();
        
        // Disable current screen.
        allscreens[currentScreenID].enabled = false;
        //allscreens[currentScreenID].children.forEach( child => child.enabled = false );
        allmodels[currentScreenID].enabled = false;
        
        // Enable next screen.
        if (isNext) { 
            currentScreenID++; 
        }
        else {
            currentScreenID--;
            if ([1,2,4].includes(currentScreenID)) currentScreenID = 1;
        }
        allscreens[currentScreenID].enabled = true;
        //allscreens[currentScreenID].children.forEach( child => child.enabled = true );
        allmodels[currentScreenID].enabled = true;
        // if (isNext && currentScreenID == 13) {
        //     this.app.gameController.showSpawnedPills(true);
        // } else if (!isNext && currentScreenID == 12) {
        //     this.app.gameController.showSpawnedPills(false);
        // }
        
        if (isNext) {
            const arCamera = this.arCamera;
            const bgCamera = this.bgCamera;
            if (!arCamera.enabled) {
                arCamera.enabled = true;
                bgCamera.enabled = false;
            }
        }
        
        console.log("Showing " + currentScreenID + " " + allscreens[currentScreenID].name + " || " + allmodels[currentScreenID].name);
        // Trigger particle effects.
        var pZoom = this.pfxZoom;
        pZoom.particlesystem.reset();
        pZoom.particlesystem.play();
        
        this.backElementEntity.enabled = currentScreenID > 0;        
        this.app.fire('progressIndicator', (currentScreenID >= 14 ? currentScreenID+17 : currentScreenID) / 31);
    } else{
        sfx.sound.play("buzzA");
    }
};

ManagerFlow.prototype.reloadScene = function () {
    // Get a reference to the scene's root object
    var oldHierarchy = this.app.root.findByName ('Root');
    
    // Get the path to the scene
    var scene = this.app.scene; // this.app.scenes.find(sceneName);
    
    // Load the scenes entity hierarchy
    this.app.scenes.loadSceneHierarchy(scene.url, function (err, parent) {
        if (!err) {
            oldHierarchy.destroy();
        } else {
            console.error(err);
        }
    });
};

ManagerFlow.prototype.startBLE = function() {
    if (this.app.ble) return;
    const app = this.app;
    app.ble = new p5ble();
    app.ble.connect("19b10000-e8f2-537e-4f6c-d104768a1214", (error, characteristics) => {
        if (error) {
            console.log('error: ', error);
            return;
        }
        if (!characteristics) {
            console.warn('no characteristics');
            return;
        }
        console.log('characteristics: ', characteristics);
    });
};