var TweenHealthBar = pc.createScript('tweenHealthBar');


TweenHealthBar.attributes.add('healthbarParent', {
    type: 'entity'
});

TweenHealthBar.attributes.add('healthbar', {
    type: 'entity'
});

TweenHealthBar.attributes.add('warning', {
    type: 'entity',
    array: true
});

TweenHealthBar.attributes.add('initDelay', {
    type: 'number',
    default: 0,
    title: 'Initial Delay [in ms]'
});

TweenHealthBar.attributes.add('tweenSpeed', {
    type: 'number',
    default: 0
});

TweenHealthBar.attributes.add('barStartColor', {
    type: 'rgb',
});
TweenHealthBar.attributes.add('barEndColor', {
    type: 'rgb',
});
TweenHealthBar.attributes.add('curveColor', { type: 'curve' });

// initialize code called once per entity
TweenHealthBar.prototype.initialize = function() {
    this.init();
    this.enter();
    
    this.on('enable', function () {
        this.enter();
    });
    
    this.on('disable', function () {
        this.init();
    });
};

TweenHealthBar.prototype.init = function() {
    var self = this;
    var barMask = self.healthbarParent;
    var bar = self.healthbar;
    var colFrom = self.barStartColor;
    var warning = self.warning;

    barMask.element.width = 0;
    bar.element.color = colFrom;
    for(var i = 0; i < warning.length; i++){
        warning[i].element.enabled = false;
    }
    //warning.element.enabled = false;
};

// update code called every frame
TweenHealthBar.prototype.enter = function() {
    var self = this;
    var initDelay = self.initDelay;
    var speed = self.tweenSpeed;
    var barMask = self.healthbarParent;
    var bar = self.healthbar;
    var warning = self.warning;
    
    var colFrom = self.barStartColor;
    var colTo = self.barEndColor;
    var colCurve = self.curveColor;
    
    var tweenHealth;
    var dataHealth = {val : 0};

    var ble = this.app.ble;
    var bleCharacteristics = this.app.bleCharacteristics;
    
    let lastSentBleVal;
    setTimeout(function(){
        
        tweenHealth = self.entity.tween(dataHealth)
        .to({ val: 1.0 }, speed, pc.Linear)
        .on('update', function(dt) {
            // Fixed tween of bar mask width.
            var v = dataHealth.val; 
            var curveValue = colCurve.value(v);
            var lerpWidth = pc.math.lerp(0, 822, curveValue);
            barMask.element.width = lerpWidth;
            
            // Fixed tween of bar color from green to red.
            var tweenR = pc.math.lerp(colFrom.r, colTo.r, curveValue);
            var tweenG = pc.math.lerp(colFrom.g, colTo.g, curveValue);
            var tweenB = pc.math.lerp(colFrom.b, colTo.b, curveValue);
            
            bar.element.color = new pc.Color(tweenR, tweenG, tweenB);
            
            // Show warning sign after threshold in value.
            if(v > 0.333){
                //warning.element.enabled = true;
                for(var i = 0; i < warning.length; i++){
                    warning[i].element.enabled = true;
                }
            }if(v >= 1){
                //warning.element.enabled = false;
            }

            if (ble && bleCharacteristics) {
                let val = v / 0.2;
                val = Math.floor(val);
                if (lastSentBleVal !== val) {
                    lastSentBleVal = val;
                    console.log('ble', `${val}`);
                    ble.write(bleCharacteristics, `${val}`);
                }
            }
        });
        
        tweenHealth.start();
        
    }, initDelay);
};
