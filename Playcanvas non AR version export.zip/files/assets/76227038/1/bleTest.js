var BleTest = pc.createScript('bleTest');

const serviceUuid = "19b10000-e8f2-537e-4f6c-d104768a1214";
let myCharacteristic;
let myBLE;

BleTest.attributes.add('buttonStart', { type: 'entity' });

BleTest.attributes.add('button0', { type: 'entity' });
BleTest.attributes.add('button1', { type: 'entity' });
BleTest.attributes.add('button2', { type: 'entity' });
BleTest.attributes.add('button3', { type: 'entity' });
BleTest.attributes.add('button4', { type: 'entity' });

BleTest.attributes.add('uiDamageBarMask', {type: 'entity'});
BleTest.attributes.add('uiDamageBarSprite', {type: 'entity'});
BleTest.attributes.add('uiDamageBarFromColour', { type: 'rgb', default: [1, 1, 1] } );
BleTest.attributes.add('uiDamageBarToColour', { type: 'rgb', default: [1, 1, 1] } );

// initialize code called once per entity
BleTest.prototype.initialize = function() {
    this._damageBarMaskFullWidth = this.uiDamageBarMask.element.width;

    this.buttonStart.element.on('click', function(event) {
        console.log('start');
        this.start();
    }, this);

    this.button0.element.on('click', function(event) {
        if (myBLE) myBLE.write(myCharacteristic, '0');
        this.setDamagePct(0);
    }, this);

    this.button1.element.on('click', function(event) {
        if (myBLE) myBLE.write(myCharacteristic, '1');
        this.setDamagePct(0.25);
    }, this);

    this.button2.element.on('click', function(event) {
        if (myBLE) myBLE.write(myCharacteristic, '2');
        this.setDamagePct(0.5);
    }, this);

    this.button3.element.on('click', function(event) {
        if (myBLE) myBLE.write(myCharacteristic, '3');
        this.setDamagePct(0.75);
    }, this);

    this.button4.element.on('click', function(event) {
        if (myBLE) myBLE.write(myCharacteristic, '4');
        this.setDamagePct(1);
    }, this);
};

BleTest.prototype.start = function() {
    myBLE = new p5ble();
    var buttonStart = this.buttonStart;
    myBLE.connect(serviceUuid, (error, characteristics) => {
        if (error) {
            console.log('error: ', error);
            return;
        }
        if (!characteristics) {
            console.warn('no characteristics');
            return;
        }
        console.log('characteristics: ', characteristics);
        myCharacteristic = characteristics[0];

        buttonStart.enabled = false;
    });
};

BleTest.prototype.setDamagePct = function(pct) {
    this._damagePercent = pc.math.clamp(pct, 0.0, 1.0);
    this.uiDamageBarMask.element.width = this._damagePercent * this._damageBarMaskFullWidth; 
    
    var tweenR = pc.math.lerp(this.uiDamageBarFromColour.r, this.uiDamageBarToColour.r, this._damagePercent*2);
    var tweenG = pc.math.lerp(this.uiDamageBarFromColour.g, this.uiDamageBarToColour.g, this._damagePercent*2);
    var tweenB = pc.math.lerp(this.uiDamageBarFromColour.b, this.uiDamageBarToColour.b, this._damagePercent*2);
    this.uiDamageBarSprite.element.color = new pc.Color(tweenR, tweenG, tweenB);
};
